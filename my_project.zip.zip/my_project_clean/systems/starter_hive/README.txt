Starter Hive initialized.
